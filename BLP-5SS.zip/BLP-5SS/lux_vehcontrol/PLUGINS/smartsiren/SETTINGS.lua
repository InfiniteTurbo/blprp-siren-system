smart_siren_masterswitch = true
--	Enabled Smart Siren plug-in.
smart_siren_timer = 2
--	Time in seconds 
smart_siren_runtime = 5
--	Time in seconds for smart tone to play once triggered.
press_to_trigger_count = 2
--	How many activations of the horn to trigger smart tone.
hold_to_trigger_time = 55
--	Arbitrary number near milliseconds
trigger_reset_timer = 5
--	Time in seconds before resetting the trigger counter. 